<p><strong><span class="module_name">Module</span> Supported Tags</strong></p>
<p>Use the following tags in your post template to display the content of this module</p>
<ul id="supported_tags"></ul>