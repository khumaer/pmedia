<script type="text/javascript">
jQuery(document).ready(function($){
	"use strict";

	if ($('.getting-support').length) {
		$('html, body').animate({
	        scrollTop: $('.getting-support').offset().top
	    }, 800);
	}
});
</script>