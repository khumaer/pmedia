jQuery(document).ready(function($){
	"use strict";

	$('#esml-result').DataTable({ pageLength: 50});
});