<?php

/**
 * Custom Opengraph Meta Tags
 */
function boombox_meta_tags() {

	if ( ! is_single() ) {
		return;
	}

	if ( ! boombox_get_theme_option( 'extras_gif_control_enable_sharing' ) ) {
		return;
	}

	global $post;
	$thumbnail_id = get_post_thumbnail_id( $post );

	if ( ! $thumbnail_id ) {
		return;
	}

	$thumbnail_post = get_post( $thumbnail_id );
	if ( ! $thumbnail_post ) {
		return;
	}

	if ( "image/gif" != $thumbnail_post->post_mime_type ) {
		return;
	}
	list( $thumbnail_url, $thumbnail_width, $thumbnail_height, $thumbnail_is_intermediate ) = wp_get_attachment_image_src( $thumbnail_post->ID, 'full' );

	$opengraph = PHP_EOL . '<meta property="og:type" content="video.other" />';
	$opengraph .= PHP_EOL . sprintf( '<meta property="og:url" content="%s" />', $thumbnail_url );

	echo wp_kses($opengraph, [
		'meta' => []
	]);
}

add_action( 'wp_head', 'boombox_meta_tags', 0 );


/**
 * Setup cookie consent script
 *
 * @since   2.5.5
 * @version 2.5.5
 */
function boombox_setup_setup_cookie_consent_script() {
	$script = boombox_get_theme_option( 'extras_gdpr_cookie_consent_script' );
	preg_replace( '<!--(.*?)-->', '', $script );
	if ( ! empty( $script ) ) {
		echo $script;
	}
}

add_action( 'wp_head', 'boombox_setup_setup_cookie_consent_script' );

function boombox_enqueue_bte_styles() {
	wp_enqueue_style( 'bte-styles', BOOMBOX_THEME_URL . 'css/styles.css', array(), '1.0.0' );
}

add_action( 'wp_enqueue_scripts', 'boombox_enqueue_bte_styles' );