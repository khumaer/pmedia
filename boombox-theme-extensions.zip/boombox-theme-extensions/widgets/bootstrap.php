<?php

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}

/**
 * "Recent Posts" widget
 */
require_once 'class-boombox-widget-recent-posts.php';

/**
 * "Trending Posts" widget
 */
require_once 'class-boombox-widget-trending-posts.php';

/**
 * "Picked posts" widget
 */
require_once 'class-boombox-widget-picked-posts.php';

/**
 * "Sticky sidebar" widget
 */
require_once 'class-boombox-widget-sticky-sidebar.php';

/**
 * "Sidebar Footer" widget
 */
require_once 'class-boombox-widget-sidebar-footer.php';

/**
 * "Create Post" widget
 */
require_once 'class-boombox-widget-create-post.php';

/**
 * "Related posts" widget
 */
require_once 'class-boombox-widget-related-posts.php';

/**
 * "Sidebar Navigation" widget
 */
require_once 'class-boombox-widget-sidebar-nav.php';