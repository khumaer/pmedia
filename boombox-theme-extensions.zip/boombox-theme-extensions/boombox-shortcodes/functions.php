<?php
/**
 * Shortcodes
 *
 * @package BoomBox_Theme_Extensions
 *
 */

/**
 * Contact Form
 */
include_once( BBTE_PLUGIN_PATH . '/boombox-shortcodes/contact-form.php' );

/**
 * Download
 */
include_once( BBTE_PLUGIN_PATH . '/boombox-shortcodes/download.php' );

/**
 * Content Components
 */
include_once( BBTE_PLUGIN_PATH . '/boombox-shortcodes/components.php' );