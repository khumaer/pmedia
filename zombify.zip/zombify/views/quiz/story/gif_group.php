<div class="zf-type-wrapper"><i class="zf-icon zf-icon-type-gif"></i></div>

<div class="zf-gif-container">
        <div class="zf-gif_container">
                <?php echo $this->renderGroups(['story', 'gif', 'gif'], $group_name_prefix, $data, $action, ['story', 'gif'], 'gif', '', ''); ?>
        </div>
</div>