<?php
// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}

use \CloudConvert\CloudConvert;
use \CloudConvert\Models\Job;
use \CloudConvert\Models\Task;

if ( ! class_exists( 'ZF_Converter_Cloudconvert' ) ) {

	class ZF_Converter_Cloudconvert extends ZF_Converter_Base {

		/**
		 * @var CloudConvert
		 */
		protected $cloudconvert;

		public function process( $attachment, $target_format, $create_attachment = false, $attachment_mime_type = 'image/jpeg', $source_format = null ) {

			if ( $this->create_client() ) {

				if ( is_int( $attachment ) ) {
					$attachment = get_post( $attachment );
				}

				$result_arr = $this->convert_local( $attachment, $target_format, $source_format );

				if ( isset( $result_arr["success"] ) && $result_arr["success"] === true && $create_attachment ) {

					$converted_attachment_args = [
						'guid'           => $result_arr['result']["url"],
						'post_mime_type' => $attachment_mime_type,
						'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $result_arr['result']["url"] ) ),
						'post_content'   => '',
						'post_status'    => 'inherit'
					];

					$converted_attach_id = wp_insert_attachment( $converted_attachment_args, ( isset( $result_arr["result"]["path"] ) ? $result_arr["result"]["path"] : false ), $attachment->ID );

					if ( isset( $result_arr["result"]["path"] ) ) {
						require_once( ABSPATH . 'wp-admin/includes/image.php' );

						$converted_attach_data = wp_generate_attachment_metadata( $converted_attach_id, $result_arr["result"]["path"] );
						wp_update_attachment_metadata( $converted_attach_id, $converted_attach_data );
					}

					$result_arr["attachment_id"] = $converted_attach_id;

				}

				return $result_arr;

			}

			$message = esc_html__( 'CloudConvert client not created', 'zombify' );

			$this->log( $message );

			return [ 'success' => false, 'message' => $message, 'result' => '' ];
		}

		/**
		 * Create Client
		 *
		 * @return bool
		 */
		protected function create_client() {

			if ( $this->cloudconvert ) {
				return true;
			}

			$api_key = zf_get_option( "zombify_cloudconvert_api_key" );

			if ( $api_key ) {
				$this->cloudconvert = new CloudConvert( [
					'api_key' => $api_key,
				] );

				return true;
			}

			return false;
		}

		/**
		 * @param      $attachment
		 * @param      $target_format
		 * @param null $source_format
		 *
		 * @return array
		 */
		protected function convert_local( $attachment, $target_format, $source_format = null ) {
			$success = false;
			$message = '';
			$result  = '';

			$source_path = get_attached_file( $attachment->ID );

			if ( ! $source_format ) {
				$source_format = strtolower( pathinfo( $source_path, PATHINFO_EXTENSION ) );
			}

			if ( $source_format == 'gif' && $target_format == 'mp4' ) {
				$convert_args = $this->get_gif_to_video_convert_args();

				try {
					$job = ( new Job() )
						->addTask(
							( new Task( 'import/upload', 'import-file' ) )
						)
						->addTask(
							( new Task( 'convert', 'convert-file' ) )
								->set( 'input', 'import-file' )
								->set( 'input_format', $source_format )
								->set( 'output_format', $target_format )
								->set( 'engine', $convert_args['engine'] )
								->set( 'video_codec', $convert_args['video_codec'] )
								->set( 'audio_codec', $convert_args['audio_codec'] )
								->set( 'audio_bitrate', $convert_args['audio_bitrate'] )
						)
						->addTask(
							( new Task( 'export/url', 'export-to-local' ) )
								->set( 'input', 'convert-file' )
								->set( 'inline', false )
								->set( 'archive_multiple_files', false )
						);

					$result = $this->handle_cloudconvert_job( $job, $attachment, $target_format, $source_format );

					if ( ! empty( $result ) ) {
						$success = true;
					}

				} catch ( Exception $e ) {
					$message = $e->getMessage();
					$this->log( $message );
				}
			}

			return [ 'success' => $success, 'message' => $message, 'result' => $result ];
		}

		/**
		 * @return array
		 */
		protected function get_gif_to_video_convert_args() {
			return [
				'engine'         => 'ffmpeg',
				'video_codec'    => 'x264',
				'crf'            => '23',
				//Quality of the video. Scale is 0–51, where 0 is lossless, 23 is the default, and 51 is worst quality possible
				'preset'         => 'medium',
				'subtitles_mode' => 'none',
				'audio_codec'    => 'copy',
				'audio_bitrate'  => 128
			];
		}

		/**
		 * param $job
		 *
		 * @param   $attachment
		 * @param   $target_format
		 * @param   $source_format
		 *
		 * @return array
		 * @var Job $job
		 */

		protected function handle_cloudconvert_job( $job, $attachment, $target_format, $source_format ) {
			$result      = [];
			$source_path = get_attached_file( $attachment->ID );

			if ( ! $source_format ) {
				$source_format = strtolower( pathinfo( $source_path, PATHINFO_EXTENSION ) );
			}

			$file_name       = trim( basename( $source_path, $source_format ), '.' );
			$wp_upload_dir   = wp_upload_dir();
			$output_location = sprintf( '%1$s/%2$s.%3$s', $wp_upload_dir['path'], $file_name, $target_format );

			//Upload file to CloudConvert
			$this->cloudconvert->jobs()->create( $job );
			$uploadTask = $job->getTasks()->whereName( 'import-file' )[0];
			$this->cloudconvert->tasks()->upload( $uploadTask, fopen( $source_path, 'r' ), basename( $source_path ) );
			$this->cloudconvert->jobs()->wait( $job ); // Wait for job completion

			//Download file
			foreach ( $job->getExportUrls() as $file ) {
				$source = $this->cloudconvert->getHttpTransport()->download( $file->url )->detach();
				$dest   = fopen( $wp_upload_dir['path'] . '/' . $file->filename, 'w' );

				if ( stream_copy_to_stream( $source, $dest ) ) {
					$result = [
						'path' => $output_location,
						'url'  => $wp_upload_dir['url'] . '/' . $file_name . '.' . $target_format
					];
					break;
				}
			}

			return $result;
		}

	}
}