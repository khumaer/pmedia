<?php
/**
 * Zombify Spotify Class
 */

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}

if ( ! class_exists( "Zombify_Spotify_Embed" ) ) {

	class Zombify_Spotify_Embed extends Zombify_Embed {

		public static function createEmbed( $url, $host, $cached_data, $view, $ajax, $post_id ) {
			$embed      = [];
			$thumbnail  = '';
			$url        = trim( $url );
			$url        = rtrim( $url, '/' );
			$video_type = 'Spotify';

			if ( $ajax ) {
				$result = wp_remote_get( 'https://open.spotify.com/oembed?url=' . $url, array( 'timeout' => 15 ) );
				$body   = json_decode( $result['body'] );

				if ( ! is_null( $body ) ) {
					$embed['html'] = '<div class="zf-embed-cont">' . $body->html . '</div>';
					$thumbnail = $body->thumbnail_url;
				}
			}

			if ( empty( $embed['html'] ) ) {
				$embed['html'] = '<div class="zf-embed-cont">' . parent::getWpEmbedCode( $url, $ajax, $post_id, $view ) . '</div>';
			}

			$embed['thumbnail'] = $thumbnail;
			$embed['type']      = $video_type;
			$embed['variables'] = '';
			$embed['url']       = $url;

			return $embed;
		}

	}

}