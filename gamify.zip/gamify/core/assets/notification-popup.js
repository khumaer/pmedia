(function(){

    if( ! jQuery( 'body' ).find( "#fb-root" ) ){
        jQuery( 'body' ).append( '<div id="fb-root"></div>' );
    }

    /***** Twiiter share */
    jQuery( '#gfy-share-trophy-tw' ).on( 'click', function( event ){
        event.preventDefault();

        var _dataHolder = jQuery( this ).closest( '.gfy-share-data' );
        if( _dataHolder.length ) {
            var
                url = 'https://twitter.com/intent/tweet?text=' + _dataHolder.data('description') + '&url=' + _dataHolder.data('url'),
                width = 570,
                height = 300,
                top = ( screen.height / 2 ) - ( height / 2 ),
                left = ( screen.width / 2 ) - ( width / 2 );

            window.open( url, '_blank', 'location=yes,scrollbars=yes,status=yes,width='+width+',height='+height+',top='+top+',left='+left );
        }
    } );

})();