String pipeline_config_file = 'pipeline_config.json'
String art_file_name = 'gamify_\$BUILD_NUMBER.tar.gz'
String mattermost_endpoint = 'https://chat.novembit.com/hooks/h8hro8kuojbzfqjwxubysdbxny'

// file exclusions
def pipeline_config
def cnf_excluded_common_files
def cnf_excluded_branch_files
def cnf_excluded_common_dirs
def cnf_excluded_branch_dirs
def cnf_keep_node_modules

// artifact storage host
String cnf_artifact_host
String cnf_artifact_path

// deployment host
String cnf_deploy_host
String cnf_deploy_path

def rm_file_arr(String path, files) {
	dir(path){
		for (int i=0; i < files.size(); i++) {
			String file_path = files[i].toString()
			if ( fileExists(file_path) ) {
				sh "rm -f $file_path"
			}
		}
	}
}
def rm_dir_arr(String path, dirs) {
	dir(path){
		for (int i=0; i < dirs.size(); i++) {
			String dir_path = dirs[i].toString()
			if ( fileExists(dir_path) ) {
				sh "rm -rf $dir_path"
			}
		}
	}
}
def ssh_rm_file_arr(files, String host, String path) {
	for (int i=0; i < files.size(); i++) {
		String file_path = files[i].toString()
		sh "ssh $host rm -f $path/$file_path"
	}
}
def ssh_rm_dir_arr(dirs, String host, String path) {
	for (int i=0; i < dirs.size(); i++) {
		String dir_path = dirs[i].toString()
		sh "ssh $host rm -rf $path/$dir_path"
	}
}

def git_checkout(String path, String creds, String url, String branch){
	Boolean succeeded = false
	dir (path) {
		try {
			git branch: branch,
					credentialsId: creds,
					url: url
			succeeded = true
		} catch (Throwable ex) {
			echo 'could not checkout, trying to remove the directory and clone again'
		}
	}
	if( !succeeded ){
		dir (path) {deleteDir()}
		sh "mkdir -p $path"
		dir (path) {
			git branch: branch,
					credentialsId: creds,
					url: url
		}
	}
}
def gamify_checkout(String path, String branch){
	git_checkout(path, 'da12646f-1194-4eda-9ed2-cdb4d6fa0b74', 'git@gitlab.novembit.com:rafik/gamify.git', branch)
}

try {
	mattermostSend endpoint: mattermost_endpoint, message: "Build Started: $BRANCH_NAME $BUILD_NUMBER", color: "good"
	node {
		stage('Fetching source') {
			echo 'Running fetching source stage ...'
			echo 'Should be done - git checkout gamify'

			// clean previous build temporary folders if any
			parallel(
					"clean_temp": {
						dir('./temp') { deleteDir() }
					},
					"clean_temp_tmp": {
						dir('./temp@tmp') { deleteDir() }
					},
					"clean_build": {
						dir('./build') { deleteDir() }
					},
					"clean_build_tmp": {
						dir('./build@tmp') { deleteDir() }
					}
			)

			parallel(
					"prepare_dir_checkout": {
						if (!fileExists('./checkout')) {
							sh "mkdir ./checkout"
						}
					},
					"prepare_dir_temp": {
						sh "mkdir -p ./temp"
					},
					"prepare_dir_build": {
						sh "mkdir -p ./build"
					},
			)

			gamify_checkout('./checkout', BRANCH_NAME)

			// init config variables from config json file
			pipeline_config = readJSON file: "./checkout/$pipeline_config_file"
			cnf_excluded_common_files = pipeline_config['exclude']['common']['file']
			cnf_excluded_branch_files = pipeline_config['exclude'][BRANCH_NAME]['file']
			cnf_excluded_common_dirs = pipeline_config['exclude']['common']['dir']
			cnf_excluded_branch_dirs = pipeline_config['exclude'][BRANCH_NAME]['dir']
			cnf_keep_node_modules = pipeline_config['keep_node_modules'][BRANCH_NAME]

			cnf_artifact_keep = pipeline_config['artifact_keep'][BRANCH_NAME]
			cnf_artifact_host = pipeline_config['artifact_host'].toString()
			cnf_artifact_path = pipeline_config['artifact_path'].toString()

			cnf_deploy_host = pipeline_config['deploy_host'].toString()
			cnf_deploy_path = pipeline_config['deploy_path'][BRANCH_NAME].toString()

			sh "cp -R ./checkout/. ./temp"

			echo 'Done fetching source stage.'
		}
		stage('Build') {
			echo 'Running Build stage ...'
			echo 'Should be done - run gulp'

			// check node_modules to move inside the ./temp
			if (fileExists('./node_modules')) {
				echo 'using existing node_modules'
				// sh "mv ./node_modules/ ./temp/node_modules/"
			}
			dir('./temp') {
				withDockerContainer(args: '-v /var/lib/jenkins/builder_cache:/home/builder/.cache -v /var/lib/jenkins/npm_cache:/home/builder/.npm',
						image: 'novembit/php_build:jenkins') {
					// sh "npm install --verbose && gulp build"
				}
			}
			parallel(
					"delete_common_excluded_files": {
						rm_file_arr('./temp', cnf_excluded_common_files)
					},
					"delete_branch_excluded_files": {
						rm_file_arr('./temp', cnf_excluded_branch_files)
					},
					"save_node_modules": {
						if (cnf_keep_node_modules) {
							// todo -hovo
							// sh "cp -R ./temp/node_modules/. ./node_modules"
						} else {
							// todo -hovo
							// sh "mv ./temp/node_modules ./node_modules"
						}
					}
			)
			echo 'delete common and branch excluded directories'
			rm_dir_arr('./temp', cnf_excluded_common_dirs)
			rm_dir_arr('./temp', cnf_excluded_branch_dirs)

			echo 'creating archive'
			dir('./temp') {
				sh "tar -czf ../build/$art_file_name ."
			}

			echo 'Done Build stage.'
		}
		stage('Testing') {
			echo 'Running Testing stage ...'
			echo 'Should be done - no tests for now'
			echo 'Done Testing stage.'
		}
		stage('Stash artifact in dev host ...') {
			echo 'Running stash artifact in dev host stage ...'
			echo 'Should be done - setup under the dev hosting /gamify-{branch}'

			if (cnf_artifact_keep) {
				echo 'save the artifact'
				sh "ssh $cnf_artifact_host mkdir -p $cnf_artifact_path$BRANCH_NAME"
				sh "scp -rp ./build/$art_file_name $cnf_artifact_host:'$cnf_artifact_path$BRANCH_NAME/'"
			} else {
				echo 'branch is configured not to save the artifact'
			}

			echo 'Done stash artifact in dev host stage.'
		}
		stage('Deployment') {
			echo 'Running Deployment stage ...'
			echo 'Should be done - update dev host instance'

			echo 'remove old theme directories from the deployment hosting'
			// todo
			sh "ssh $cnf_deploy_host rm -rf $cnf_deploy_path"
			sh "ssh $cnf_deploy_host mkdir -p $cnf_deploy_path"

			parallel(
					"delete_common_excluded_files_from_deployment_hosting": {
						ssh_rm_file_arr(cnf_excluded_common_files, cnf_deploy_host, cnf_deploy_path)
					},
					"delete_branch_excluded_files_from_deployment_hosting": {
						ssh_rm_file_arr(cnf_excluded_branch_files, cnf_deploy_host, cnf_deploy_path)
					}
			)
			echo 'delete common and branch excluded directories from deployment hosting'
			ssh_rm_dir_arr(cnf_excluded_common_dirs, cnf_deploy_host, cnf_deploy_path)
			ssh_rm_dir_arr(cnf_excluded_branch_dirs, cnf_deploy_host, cnf_deploy_path)

			echo 'copy and extract new files into the deployment hosting'
			sh "scp -p ./build/$art_file_name $cnf_deploy_host:'$cnf_deploy_path/'"
			sh "ssh $cnf_deploy_host tar -xf $cnf_deploy_path/$art_file_name -C $cnf_deploy_path/ "

			echo 'remove the archive file from the deployment hosting'
			sh "ssh $cnf_deploy_host rm -f $cnf_deploy_path/$art_file_name"

			echo 'Done Deployment stage.'
		}
		stage('Cleanup') {
			echo 'Running Cleanup stage ...'
			echo 'Should be done - clean temporary directories'

			// clean temporary folders if any
			parallel(
					"clean_temp": {
						dir('./temp') { deleteDir() }
					},
					"clean_temp_tmp": {
						dir('./temp@tmp') { deleteDir() }
					},
					"clean_build": {
						dir('./build') { deleteDir() }
					},
					"clean_build_tmp": {
						dir('./build@tmp') { deleteDir() }
					}
			)

			echo 'Done Cleanup stage.'
		}
	}
	mattermostSend endpoint: mattermost_endpoint, message: "Build Succeeded: $BRANCH_NAME $BUILD_NUMBER", color: "good"
} catch (Throwable ex) {
	mattermostSend endpoint: mattermost_endpoint, message: "Build Failed: $BRANCH_NAME $BUILD_NUMBER", text: ex.toString(), color: "danger"
	throw ex
}