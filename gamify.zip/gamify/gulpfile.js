/*jshint esversion: 6 */

const gulp      = require( 'gulp' );
const minifycss         = require( 'gulp-clean-css' );
const uglify            = require( 'gulp-uglify-es' ).default;
const concat            = require( 'gulp-concat' );
const wpPot     = require( 'gulp-wp-pot' );
const zip       = require( 'gulp-zip' );
const replace   = require( 'gulp-replace' );
const argv      = require( 'yargs' ).argv;

const log = function( val ){
    console.log( val );
}

/**
 * Minify admin css files
 */
function minify_back_css() {
    return Promise.all([
        new Promise( function( resolve, reject ){
            gulp.src( 'core/admin/assets/css/repeater.css' )
                .pipe(minifycss())
                .pipe( concat( 'repeater.min.css' ) )
                .pipe( gulp.dest( 'core/admin/assets/css/' ) )
                .on( 'error', function( err ){
                    log( err );
                    reject( err );
                } )
                .on( 'end', function(){
                    resolve();
                } );
        } )
    ]);
}

/**
 * Minify admin js files
 */
function minify_back_js() {
    return Promise.all([
        new Promise( function( resolve, reject ) {
            gulp.src( 'core/admin/assets/js/repeater.js' )
                .pipe( concat('repeater.min.js') )
                .pipe( uglify() )
                .pipe( gulp.dest( 'core/admin/assets/js/') )
                .on( 'error', function( err ){
                    log( err );
                    reject( err );
                } )
                .on( 'end', function(){
                    resolve();
                } );
        } )
    ]);
}

/**
 * Build assets
 */
function build() {
    return minify_back_css()
        .then( minify_back_js() );
}

/**
 * Generate .pot file
 * @returns {*|PromisePolyfill}
 */
function generate_pot_file() {
    return new Promise( function( resolve, reject ){
        gulp.src([
            '**/*.php',
            '!node_modules',
            '!languages'
        ])
            .pipe( wpPot( { relativeTo: '../', package: 'gamify' } ) )
            .pipe( gulp.dest( 'languages/gamify.pot' ) )
            .on( 'error', function( err ){
                log( err );
                reject( err );
            } )
            .on( 'end', function(){
                resolve();
            } );
    } );
}

/**
 * Build plugin zip file
 * @returns {*|PromisePolyfill}
 */
function plugin_build_zip() {
    return new Promise( function( resolve, reject ){
        gulp.src([
            '../gamify/**/*.*',
            '!../gamify/node_modules/',
            '!../gamify/node_modules/**/*',
            '!../gamify/.gitignore',
            '!../gamify/gulpfile.js',
            '!../gamify/Jenkinsfile.groovy',
            '!../gamify/package.json',
            '!../gamify/pipeline_config.json'
        ], { base: '../../plugins' })
            .pipe( zip( 'gamify.zip' ) )
            .pipe( gulp.dest( '../' ) )
            .on( 'error', function( err ){
                log( err );
                reject( err );
            } )
            .on( 'end', function(){
                resolve();
            } );
    } );
}

/**
 * Change plugin version
 * @returns {*|PromisePolyfill}
 */
function change_version() {
    return new Promise( function( resolve, reject){
        if( /(^\d{1,2}\.\d{1,2}(\.\d{1,2})?(\.\d{1,2})?)$/.test( argv.gfy_ver ) ) {
            gulp.src( 'gamify.php' )
                .pipe( replace( /^[ \t\/*#@]*Version:(.*)$/mi, function( match, p1, offset, string ){
                    return match.replace( p1.trim(), argv.gfy_ver );
                } ) )
                .pipe( gulp.dest( './' ) )
                .on( 'error', function( err ){
                    log( err );
                    reject( err );
                } )
                .on( 'end', function(){
                    resolve();
                } );
        } else {
            resolve();
        }
    } );
}

/***** Back styles */
gulp.task( 'admin-css', function(){
    return minify_back_css();
} );
gulp.task('css-watch', function() {
    gulp.watch( 'core/admin/assets/css/*.css', gulp.series( 'admin-css' ) );
});
/***** -/end Back styles */

/***** Back scripts */
gulp.task( 'admin-js', function(){
    return minify_back_js();
} );
gulp.task('js-watch', function() {
    gulp.watch( 'core/admin/assets/js/*.js', gulp.series( 'admin-js' ) );
});
/***** -/end Back scripts */

/***** .POT */
gulp.task('generate-pot', function () {
    return generate_pot_file();
});
/***** -/end .POT */

/***** ZIP plugin */
gulp.task( 'generate-plugin-zip', function(){
    return plugin_build_zip();
} );
/***** -/end ZIP plugin */

/***** Build assets */
gulp.task( 'build', function(){
    return build();
} );
/***** -/end Build assets */

/***** Create plugin release package */
gulp.task('build-release', function(){
    return change_version()
        .then( build )
        .then( generate_pot_file )
        .then( plugin_build_zip );
});
/***** -/end Create plugin release package */