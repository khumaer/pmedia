<?php return array(
    'root' => array(
        'name' => 'kirki-framework/kirki',
        'pretty_version' => '5.0.0',
        'version' => '5.0.0.0',
        'reference' => NULL,
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'dev' => false,
    ),
    'versions' => array(
        'kirki-framework/kirki' => array(
            'pretty_version' => '5.0.0',
            'version' => '5.0.0.0',
            'reference' => NULL,
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
