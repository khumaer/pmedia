<?php

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}

/**
 * Loop Helper
 */
require_once( 'class-boombox-loop-helper.php' );